#include <iostream>
#include<fstream>
#include<sstream>
#include<string>
using namespace std;

int main()
{

    string arr[24],nam, f,s, st,temp, c;
    ifstream name ("comp_name.txt");
    if (name.is_open())
    {
        int co =0;
        while(getline(name, nam))
        {
            arr[co]=nam;
            co++;

        }
        name.close();

    }

    else
    {
        cout << "file not found !" << endl;


    }
    for(int i=1 ; i<24 ; i++)
    {
        int coun = 0;
        f= arr[i-1];
        s=arr[i];
        c = s.at(0);
        if( (c>="a"&&c<="z") || (c>="A"&&c<="Z") )
        {

            coun =0;

        }
        else
        {
            s.erase(0, 1) ;
            stringstream ss(c);
            ss>>coun;

        }
        if (coun!=0)
        {
            f.erase(coun, f.size());
            arr[i]=f+s;
        }



    }

    ofstream dec("deco_name.txt");
    if(dec.is_open())
    {

        for(int i=0 ; i<24 ; i++)
            dec<<arr[i]<<"\n";


    }






    return 0;
}
