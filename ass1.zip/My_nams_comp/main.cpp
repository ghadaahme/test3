#include <iostream>
#include<string>
using namespace std;
#include <fstream>
#include<sstream>
int main()
{

    string arr[24],nam,comp[24], f,s, st;
    ifstream name ("names.txt");
    if (name.is_open())
    {
        int co =0;
        while(getline(name, nam))
        {
            arr[co]=nam;
            if(co==0)
                comp[0]=nam;
            co++;

        }
        name.close();

    }

    else
    {
        cout << "file not found !" << endl;


    }
    for(int i=1 ; i<24; i++)
    {
        f=arr[i-1] ;
        int counter=0;
        stringstream ss ;

        int siz_f=f.size();
        s=arr[i];
        int siz_s=s.size();
        if(siz_f<=siz_s)
            siz_s=siz_f;

        for(int j=0 ; j<siz_s ; j++)
        {
            if(f.at(j)==s.at(j))
                counter++;
            else
            {

 j=siz_s;
            }

        }
            if (counter == 0)
                {
                    comp[i] = s ;

                }
                else
                {
                    s.erase(0, counter ) ;
                    comp[i] = s ;
                    ss << counter ;
                    st = ss.str() ;
                    comp[i].insert(0, st) ;

                }



    }
    ofstream comnam("comp_name.txt");

    if(comnam.is_open()){

    for(int i=0 ; i<24 ;i++){
        comnam<< comp[i]<<"\n";


    }
    }
    else {
    cout<<"file2 not found "<<endl;
    }

    return 0;
}
